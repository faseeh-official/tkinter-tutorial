from tkinter import *
root = Tk()

root.geometry("300x300")\
# Sets the initial size of the window.
root.resizable(width=False, height=False)
# Sets whether the window is resizable.

root.mainloop()