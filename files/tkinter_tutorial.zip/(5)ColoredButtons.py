from tkinter import*
root = Tk()

MyButton = Button(root, text = "Click me.", fg="green", bg="yellow") # fg stands for foreground color, and bg for background color.
MyButton.pack()

root.mainloop()